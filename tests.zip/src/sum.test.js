// const sum = require('./sum');
import sum from './sum';

test('test', () => {
  const l1 = [1, 5, 3, 5, 8, 9];
  expect(sum(l1)).toBe('');
});
