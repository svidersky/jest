export default function (l1) {
  let result;
  for (let i = 0; i < l1.length; i += 1) {
    result = '';
  }

  return result;
}
